from .auth import router as auth_router
from .agents import router as agents_router
from .documents import router as documents_router
from .health import router as health_router

__all__ = [
    "auth_router",
    "agents_router",
    "documents_router",
    "health_router"
]
