#!/bin/bash
set -e

echo "Starting SQA Management System Backend..."

# Install dependencies
python -m pip install --upgrade pip
pip install -r requirements.txt

# Use PORT env var or default to 8000
PORT="${PORT:-8000}"

# Start the FastAPI server with Gunicorn and Uvicorn workers
gunicorn main:app \
    --workers 2 \
    --worker-class uvicorn.workers.UvicornWorker \
    --bind 0.0.0.0:$PORT \
    --timeout 120 \
    --access-logfile - \
    --error-logfile -
